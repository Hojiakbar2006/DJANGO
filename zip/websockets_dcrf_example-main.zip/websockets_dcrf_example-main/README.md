<h2 align="center">Django Channels Rest Framework examples</h2>

Пример чата на Django Channels Rest Framework.

**Ссылки**:
- [Сайт](https://collabteam.dev)
- [YouTube](https://www.youtube.com/playlist?list=PLF-NY6ldwAWqSxUpnTBObEP21cFQxNJ7C)
- [Telegram](https://t.me/trueDjangoChannel)

### Инструменты разработки

**Стек:**
- Python >= 3.7
- Django Channels Rest Framework

## Старт

#### 1) Установить зависимости

    pip install -r req.txt

##### 2) Запустить

     daphne config.asgi:application

##### 3) Перейти по адресу

    http://127.0.0.1:8000/chat/

[BSD 3-Clause License](https://opensource.org/licenses/BSD-3-Clause)

Copyright (c) 2020-present, DJWOMS - Omelchenko Michael




