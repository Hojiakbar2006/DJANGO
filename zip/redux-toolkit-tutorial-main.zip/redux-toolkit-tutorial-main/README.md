# Redux Toolkit Tutorial

![app screenshoot](https://raw.githubusercontent.com/raaynaldo/redux-toolkit-tutorial/main/public/app-screenshoot.png)

Read the full tutorial blog [here](https://dev.to/raaynaldo/redux-toolkit-setup-tutorial-5fjf)
